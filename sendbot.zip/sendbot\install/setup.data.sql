SET FOREIGN_KEY_CHECKS=0;

INSERT INTO `{PREFIX}system_eventnames` VALUES (NULL,'OnSendBot','7','Api Bot');
